/**
 * Chat room — Client half.
 *
 * A message list in the sidebar: the left rail lists people, the main column is
 * the conversation with the selected person. Underneath, every installation has
 * one inbox topic; an add code is that inbox, so adding a contact is a single
 * paste and nobody has to "create" a conversation first. A first message from an
 * unknown sender creates the contact on the receiving side.
 *
 * The Host half owns the relay connections and exposes a same-origin API, so
 * this module only renders state and calls that API.
 */
window.__ModuleLoader__.load({
  id: 'dsh-chat-room',
  factory(require) {
    const React = require('react');
    const h = React.createElement;

    const NS = 'chatRoom';
    const PANEL_ID = 'chatroom';
    const API = '/plugin/chat-room';
    const DEFAULT_RELAY = 'https://ntfy.sh';
    const MAX_TEXT = 2000;
    const PLUGIN_ZIP = 'chat-room-1.5.3.tgz';

    /**
     * The stylesheet is injected once for the whole plugin, not by the panel:
     * the sidebar entry shows an update dot even while the panel is closed,
     * and that dot needs its rules.
     */
    function injectStyles() {
      if (typeof document === 'undefined') return;
      if (document.getElementById('dsh-msg-styles')) return;
      const style = document.createElement('style');
      style.id = 'dsh-msg-styles';
      style.textContent = CSS;
      document.head.appendChild(style);
    }

    /* ------------------------------------------------------------------ *
     * Copy
     * ------------------------------------------------------------------ */

    const DICTS = {
      zh: {
        title: '消息',
        subtitle: '粘贴添加码就能开始聊天',
        addContact: '添加联系人',
        myCode: '我的添加码',
        myCodeShort: '我的码',
        contactCount: '位联系人',
        searchPlaceholder: '搜索联系人',
        noContactsTitle: '还没有联系人',
        noContactsHint: '点「添加联系人」粘贴对方给你的添加码；把自己的添加码发给对方也可以。',
        noMessages: '还没有消息',
        noMessagesHint: '发第一条消息打个招呼吧',
        selectContact: '选择一个联系人',
        selectContactHint: '从左边点一个联系人开始聊天。',
        composerPlaceholder: '输入消息，Enter 发送，Shift+Enter 换行',
        send: '发送',
        sending: '发送中',
        failed: '发送失败',
        retry: '重试',
        relayOnline: '连接正常',
        relayConnecting: '连接中…',
        relayError: '连接异常',
        relayIdle: '未连接',
        you: '你',
        unnamed: '未命名联系人',
        addTitle: '添加联系人',
        addHint: '把对方发给你的添加码粘进来即可，不需要对方先建会话。',
        addCodeLabel: '添加码',
        addCodePlaceholder: '粘贴 DSHCHAT2: 开头的添加码',
        addButton: '添加',
        badCard: '添加码无效，请确认完整复制',
        ownCode: '这是你自己的添加码，发给对方即可',
        tooMany: '联系人数量已达上限（30 个）',
        info: '编辑',
        contactInfo: '编辑',
        renameLabel: '备注名',
        namePlaceholder: '比如：小明',
        save: '保存',
        cancel: '取消',
        close: '关闭',
        clear: '清空记录',
        clearConfirm: '再点一次确认清空',
        remove: '删除联系人',
        removeConfirm: '再点一次确认删除',
        myCodeTitle: '我的添加码',
        myCodeHint: '把下面这段发给对方。对方只需要两步：上传插件包并说一句口令，然后粘贴这行添加码。',
        copyCode: '复制添加码',
        copyCard: '复制整段说明',
        copied: '已复制',
        settingsTitle: '我的设置',
        updateTitle: '插件更新',
        updateVersion: '当前版本',
        updateSource: '更新源（npm 包名或清单地址）',
        updateSourceHint: '填 npm 包名或 https 的清单地址，插件会自己查新版本并提示更新；留空则不检查',
        updateCheck: '检查更新',
        updateInstall: '立即更新',
        updateSave: '保存更新源',
        updateAvailable: '发现新版本',
        updateUpToDate: '已是最新版本',
        updateChecking: '正在检查…',
        updateInstalling: '正在更新…',
        updateSourceSaved: '更新源已保存',
        updateNeedSource: '请先填写更新源',
        updateBadSource: '更新源只接受 npm 包名',
        updateFailed: '更新失败，请重试',
        updateNotBundle: '更新源不是一个插件包',
        updateNotPublished: '更新源还没发布新版本，或包名写错了',
        updateFake: '这是模拟的新版本，不能真的安装',
        updateSimulated: '模拟更新完成（真更新要用已发布的版本）',
        updateNoManager: '这个 DSH 里没有插件管理器，无法自动更新',
        updateBusy: '正在更新中，请稍候',
        updateManifestFailed: '读不到发布清单',
        updateDownloadFailed: '下载新版本失败',
        updateMismatch: '更新源的包名与当前插件不一致，已拒绝更新',
        myName: '我的昵称',
        defaultRelay: '中继地址',
        relayHint: '双方要用同一个中继；改这里只影响以后发给别人的添加码。',
        limitsHint: '公共中继免费版约每天 250 条、消息保留 12 小时。',
        loadError: '聊天服务没有响应',
        threadLoadError: '这个联系人的历史记录没加载出来',
        pluginHint: '对方还没装插件？把插件包和这一步说明一起发给对方。',
        waitingPeer: '等对方先说话',
        noNameYet: '未设置昵称',
        autoAdded: '对方发来消息，已自动添加',
        addedYou: '对方添加了你',
        renameHint: '点名字可以改备注',
        autoAddedInfo: '对方先发来消息，所以自动出现在你的列表里。改个备注名会好认很多。',
        newBadge: '新',
        setYourName: '点右侧齿轮改个昵称',
        emptyPreview: '还没有消息',
        badRelay: '中继地址无效',
        needName: '请先填一个备注名',
      },
      en: {
        title: 'Messages',
        subtitle: 'Paste an add code and start chatting',
        addContact: 'Add contact',
        myCode: 'My add code',
        myCodeShort: 'My code',
        contactCount: 'contacts',
        searchPlaceholder: 'Search contacts',
        noContactsTitle: 'No contacts yet',
        noContactsHint: 'Tap "Add contact" and paste the code the other person sent you, or send them your own code.',
        noMessages: 'No messages yet',
        noMessagesHint: 'Say hello to start',
        selectContact: 'Pick a contact',
        selectContactHint: 'Choose someone on the left to start chatting.',
        composerPlaceholder: 'Type a message. Enter sends, Shift+Enter adds a line',
        send: 'Send',
        sending: 'Sending',
        failed: 'Failed',
        retry: 'Retry',
        relayOnline: 'Connected',
        relayConnecting: 'Connecting…',
        relayError: 'Connection problem',
        relayIdle: 'Not connected',
        you: 'You',
        unnamed: 'Unnamed contact',
        addTitle: 'Add a contact',
        addHint: 'Paste the add code the other person sent you. They do not need to create anything first.',
        addCodeLabel: 'Add code',
        addCodePlaceholder: 'Paste the code starting with DSHCHAT2:',
        addButton: 'Add',
        badCard: 'Invalid add code; make sure it was copied completely',
        ownCode: 'That is your own add code — send it to the other person instead',
        tooMany: 'Contact limit reached (30)',
        info: 'Edit',
        contactInfo: 'Edit',
        renameLabel: 'Display name',
        namePlaceholder: 'e.g. Alex',
        save: 'Save',
        cancel: 'Cancel',
        close: 'Close',
        clear: 'Clear history',
        clearConfirm: 'Click again to clear',
        remove: 'Remove contact',
        removeConfirm: 'Click again to remove',
        myCodeTitle: 'My add code',
        myCodeHint: 'Send this block to the other person. They need two steps: install the plugin and say one phrase, then paste this code.',
        copyCode: 'Copy code',
        copyCard: 'Copy whole note',
        copied: 'Copied',
        settingsTitle: 'My settings',
        updateTitle: 'Plugin updates',
        updateVersion: 'Current version',
        updateSource: 'Update source (npm package name or manifest address)',
        updateSourceHint: 'With a package name or an https manifest address the plugin checks for new versions itself; empty means it never checks',
        updateCheck: 'Check for updates',
        updateInstall: 'Update now',
        updateSave: 'Save update source',
        updateAvailable: 'A new version is available',
        updateUpToDate: 'You are up to date',
        updateChecking: 'Checking…',
        updateInstalling: 'Installing…',
        updateSourceSaved: 'Update source saved',
        updateNeedSource: 'Set an update source first',
        updateBadSource: 'The update source must be an npm package name',
        updateFailed: 'The update failed, please try again',
        updateNotBundle: 'The update source is not a plugin package',
        updateNotPublished: 'Nothing is published under that name yet, or the name is wrong',
        updateFake: 'This version is simulated, so it cannot really be installed',
        updateSimulated: 'Simulated update finished (a real one needs a published version)',
        updateNoManager: 'This DSH has no plugin manager, so it cannot update itself',
        updateBusy: 'An update is already running, please wait',
        updateManifestFailed: 'The release manifest could not be read',
        updateDownloadFailed: 'The new version could not be downloaded',
        updateMismatch: 'The update source names a different package, so the update was refused',
        myName: 'My name',
        defaultRelay: 'Relay',
        relayHint: 'Both sides must use the same relay. Changing it only affects codes you send later.',
        limitsHint: 'The public relay allows about 250 messages a day and keeps them for 12 hours.',
        loadError: 'The chat service did not respond',
        threadLoadError: 'History for this contact did not load',
        pluginHint: 'Other person has no plugin yet? Send them the package with the one-step install note.',
        waitingPeer: 'Waiting for them to speak',
        noNameYet: 'No display name yet',
        autoAdded: 'They wrote first, so they were added automatically',
        addedYou: 'They added you',
        renameHint: 'Click a name to rename it',
        autoAddedInfo: 'They wrote first, so they appeared in your list automatically. Give them a display name so you recognize them.',
        newBadge: 'NEW',
        setYourName: 'Tap the gear to set your name',
        emptyPreview: 'No messages yet',
        badRelay: 'That relay address is not valid',
        needName: 'Enter a display name first',
      },
    };

    /* ------------------------------------------------------------------ *
     * Helpers: URLs, formatting, merging
     * ------------------------------------------------------------------ */

    function normalizeRelay(value) {
      if (typeof value !== 'string') return null;
      const trimmed = value.trim().replace(/\/+$/, '');
      if (!trimmed) return null;
      let parsed;
      try {
        parsed = new URL(trimmed);
      } catch (err) {
        return null;
      }
      if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') return null;
      if (parsed.search || parsed.hash) return null;
      return parsed.origin + parsed.pathname.replace(/\/+$/, '');
    }

    function formatTime(at) {
      const date = new Date(at);
      if (!Number.isFinite(date.getTime())) return '';
      try {
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      } catch (err) {
        return '';
      }
    }

    function shortTime(at) {
      const date = new Date(at);
      if (!Number.isFinite(date.getTime())) return '';
      const now = new Date();
      try {
        if (
          date.getFullYear() === now.getFullYear() &&
          date.getMonth() === now.getMonth() &&
          date.getDate() === now.getDate()
        ) {
          return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        }
        return date.toLocaleDateString([], { month: 'numeric', day: 'numeric' });
      } catch (err) {
        return '';
      }
    }

    function initial(name) {
      const trimmed = (name || '').trim();
      if (!trimmed) return '·';
      const first = Array.from(trimmed)[0] || '·';
      return first.toUpperCase();
    }

    function upsertMessage(list, message) {
      const messages = Array.isArray(list) ? list.slice() : [];
      const index = messages.findIndex((entry) => entry.id === message.id);
      if (index >= 0) messages[index] = message;
      else {
        messages.push(message);
        if (messages.length > 400) messages.splice(0, messages.length - 400);
      }
      return messages;
    }

    function sortContacts(contacts) {
      return contacts.slice().sort((left, right) => {
        const leftAt = left.lastMessage ? left.lastMessage.at : left.createdAt || 0;
        const rightAt = right.lastMessage ? right.lastMessage.at : right.createdAt || 0;
        return rightAt - leftAt;
      });
    }

    function statusLabel(status, t) {
      if (status === 'online') return t('relayOnline');
      if (status === 'connecting') return t('relayConnecting');
      if (status === 'error') return t('relayError');
      return t('relayIdle');
    }

    function activeLang(locale) {
      try {
        const snapshot =
          locale && typeof locale.getSnapshot === 'function' ? locale.getSnapshot() : null;
        const active = snapshot ? snapshot.active : '';
        const id =
          typeof active === 'string'
            ? active
            : active && typeof active.id === 'string'
              ? active.id
              : '';
        return String(id).toLowerCase().indexOf('zh') === 0 ? 'zh' : 'en';
      } catch (err) {
        return 'zh';
      }
    }

    function buildCardText(lang, { name, code }) {
      if (lang === 'en') {
        return [
          'DSH add code' + (name ? ' — ' + name : ''),
          '',
          'Step 1 — install the plugin (one approval in total):',
          '• Drop ' + PLUGIN_ZIP + ' into the DSH message box and say:',
          '  "Use plugin_manager to install the ' + PLUGIN_ZIP + ' I just uploaded. Only call plugin_manager for this, do not run any other commands."',
          '• If DSH says the plugin_manager tool is unavailable, switch the mode selector at the top right from Standard to Creator and send it again.',
          '• Approve once when asked: the plugin has no dependencies and runs no install scripts.',
          '• The add code in step 2 carries the update address, so the plugin can check for new versions on its own.',
          'Step 2 — add me: open the Messages panel, tap "Add contact" and paste the code below:',
          '',
          code,
          '',
          'Once those two steps are done we can chat here in real time.',
        ].join('\n');
      }
      return [
        '【DSH 添加码】' + (name ? name : ''),
        '',
        '第 1 步（装插件，全程只要 1 次授权）：',
        '· 把我发你的 ' + PLUGIN_ZIP + ' 拖进 DSH 输入框，然后说一句：',
        '  「用 plugin_manager 安装我刚上传的 ' + PLUGIN_ZIP + '，只调用 plugin_manager 这一步，不要执行其它命令」',
        '· 如果 DSH 说没有 plugin_manager 工具：把右上角模式从「标准模式」切成「Creator 模式」再发一次。',
        '· 弹出授权时点「允许一次」即可：插件没有依赖、不跑任何安装脚本。',
        '· 装好后第 2 步的添加码会把「更新地址」一起带给你，之后插件能自己检查新版本，不用再找我要安装包。',
        '第 2 步（加我）：打开 DSH 左侧「消息」面板，点「添加联系人」，把下面这行添加码粘进去：',
        '',
        code,
        '',
        '两步做完，我们就能直接在这里聊天了。',
      ].join('\n');
    }

    /* ------------------------------------------------------------------ *
     * Artwork
     * ------------------------------------------------------------------ */

    function contactsGlyph(size, extraProps) {
      return h(
        'svg',
        Object.assign(
          {
            viewBox: '0 0 24 24',
            width: size,
            height: size,
            fill: 'none',
            stroke: 'currentColor',
            strokeWidth: 1.7,
            strokeLinecap: 'round',
            strokeLinejoin: 'round',
            'aria-hidden': true,
            focusable: 'false',
            style: { display: 'block' },
          },
          extraProps,
        ),
        [
          h('circle', { key: 'head', cx: 9.2, cy: 8.4, r: 3.1 }),
          h('path', { key: 'body', d: 'M3.6 19.1c.5-3 2.8-4.7 5.6-4.7s5.1 1.7 5.6 4.7' }),
          h('path', { key: 'list-1', d: 'M17.2 8.4h3.2' }),
          h('path', { key: 'list-2', d: 'M17.2 12h3.2' }),
          h('path', { key: 'list-3', d: 'M17.2 15.6h2.2' }),
        ],
      );
    }

    function plusGlyph(size) {
      return h(
        'svg',
        {
          viewBox: '0 0 16 16',
          width: size,
          height: size,
          fill: 'none',
          stroke: 'currentColor',
          strokeWidth: 1.8,
          strokeLinecap: 'round',
          'aria-hidden': true,
          focusable: 'false',
          style: { display: 'block' },
        },
        h('path', { d: 'M8 3.5v9M3.5 8h9' }),
      );
    }

    function copyGlyph(size) {
      return h(
        'svg',
        {
          viewBox: '0 0 16 16',
          width: size,
          height: size,
          fill: 'none',
          stroke: 'currentColor',
          strokeWidth: 1.5,
          strokeLinecap: 'round',
          strokeLinejoin: 'round',
          'aria-hidden': true,
          focusable: 'false',
          style: { display: 'block' },
        },
        [
          h('rect', { key: 'back', x: 5.4, y: 2.2, width: 8.2, height: 8.2, rx: 1.7 }),
          h('path', {
            key: 'front',
            d: 'M10.2 11.6v.9A1.9 1.9 0 0 1 8.3 14.4H4.3a1.9 1.9 0 0 1-1.9-1.9V8.5a1.9 1.9 0 0 1 1.9-1.9h.9',
          }),
        ],
      );
    }

    function pencilGlyph(size) {
      return h(
        'svg',
        {
          viewBox: '0 0 16 16',
          width: size,
          height: size,
          fill: 'none',
          stroke: 'currentColor',
          strokeWidth: 1.4,
          strokeLinecap: 'round',
          strokeLinejoin: 'round',
          'aria-hidden': true,
          focusable: 'false',
          style: { display: 'block' },
        },
        [
          h('path', { key: 'pencil', d: 'M10.6 2.9l2.5 2.5-7.4 7.4-3.1.6.6-3.1z' }),
          h('path', { key: 'tip', d: 'M9.4 4.1l2.5 2.5' }),
        ],
      );
    }

    function gearGlyph(size) {
      // A cog with eight teeth: the old glyph read as a sun.
      return h(
        'svg',
        {
          viewBox: '0 0 24 24',
          width: size,
          height: size,
          fill: 'none',
          stroke: 'currentColor',
          strokeWidth: 2,
          strokeLinecap: 'round',
          strokeLinejoin: 'round',
          'aria-hidden': true,
          focusable: 'false',
          style: { display: 'block' },
        },
        [
          h('circle', { key: 'hub', cx: 12, cy: 12, r: 3 }),
          h('path', {
            key: 'cog',
            d: 'M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z',
          }),
        ],
      );
    }

    function closeGlyph(size) {
      return h(
        'svg',
        {
          viewBox: '0 0 16 16',
          width: size,
          height: size,
          fill: 'none',
          stroke: 'currentColor',
          strokeWidth: 1.6,
          strokeLinecap: 'round',
          'aria-hidden': true,
          focusable: 'false',
          style: { display: 'block' },
        },
        h('path', { d: 'M4.2 4.2l7.6 7.6M11.8 4.2l-7.6 7.6' }),
      );
    }


    /* ------------------------------------------------------------------ *
     *  Update watcher
     *
     *  The sidebar entry lives outside the panel, so it needs its own view
     *  of the update state. One watcher feeds every consumer.
     * ------------------------------------------------------------------ */
    const updateWatch = {
      available: false,
      version: '',
      listeners: new Set(),
      started: false,
    };

    function publishUpdateWatch(state) {
      const update = (state && state.update) || null;
      const available = Boolean(update && update.available);
      const version = (update && update.latest) || '';
      if (available === updateWatch.available && version === updateWatch.version) return;
      updateWatch.available = available;
      updateWatch.version = version;
      for (const listener of updateWatch.listeners) listener(available, version);
    }

    function startUpdateWatch() {
      if (updateWatch.started || typeof window === 'undefined') return;
      updateWatch.started = true;
      const base = '/plugin/chat-room';
      const read = async () => {
        try {
          const response = await fetch(base + '/state', { headers: { accept: 'application/json' } });
          const body = await response.json();
          if (body && body.ok && body.state) publishUpdateWatch(body.state);
        } catch (error) {
          /* the panel shows the connection error */
        }
      };
      void read();
      try {
        const source = new EventSource(base + '/events');
        source.addEventListener('state', (event) => {
          try {
            // The frame carries the state itself, not a wrapper.
            const frame = JSON.parse(event.data);
            publishUpdateWatch(frame && frame.state ? frame.state : frame);
          } catch (error) {
            /* ignore a broken frame */
          }
        });
      } catch (error) {
        /* no live updates without a stream */
      }
    }

    function useUpdateWatch() {
      const [value, setValue] = React.useState({
        available: updateWatch.available,
        version: updateWatch.version,
      });
      React.useEffect(() => {
        startUpdateWatch();
        const listener = (available, version) => setValue({ available, version });
        updateWatch.listeners.add(listener);
        return () => updateWatch.listeners.delete(listener);
      }, []);
      return value;
    }

    /** The update dot. It carries its own rules as well, so a missing
     *  stylesheet can never leave it invisible. */
    function updateDot(extra) {
      return h('span', {
        className: 'dsh-msg-update-dot' + (extra ? ' ' + extra : ''),
        style: {
          position: 'absolute',
          display: 'block',
          width: '6px',
          height: '6px',
          borderRadius: '999px',
          background: 'var(--dsw-alias-state-error-primary)',
          pointerEvents: 'none',
        },
      });
    }

    function ContactIcon(props) {
      const size = props && typeof props.size === 'number' && props.size > 0 ? props.size : 20;
      const active = !!(props && props.active);
      const update = useUpdateWatch();
      // The translator is bound inside apply(), so it comes in as a prop. A
      // missing one must never take the sidebar row down with it.
      const translate = props && typeof props.t === 'function' ? props.t : null;
      const title = update.available
        ? (translate ? translate('updateAvailable') : 'New version') + ' ' + update.version
        : undefined;
      return h(
        'span',
        {
          className: 'dsh-msg-icon',
          title,
          style: {
            position: 'relative',
            display: 'inline-flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: active ? 'var(--dsw-alias-label-primary)' : 'var(--dsw-alias-label-secondary)',
          },
        },
        contactsGlyph(size),
        update.available ? updateDot('dsh-msg-update-dot--icon') : null,
      );
    }

    /* ------------------------------------------------------------------ *
     * Styles: theme tokens only, rendered as a <style> element so unmounting
     * removes them.
     * ------------------------------------------------------------------ */

    const CSS = [
      '.dsh-msg-root{position:relative;display:flex;height:100%;min-height:0;overflow:hidden;background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-primary);font-family:inherit;font-size:13px;line-height:1.5}',
      '.dsh-msg-rail{display:flex;flex-direction:column;flex:0 0 288px;width:288px;min-width:0;border-right:1px solid var(--dsw-alias-border-l1)}',
      '.dsh-msg-rail-head{display:flex;align-items:center;gap:8px;flex:0 0 auto;padding:14px 16px 10px}',
      '.dsh-msg-rail-mark{display:inline-flex;color:var(--dsw-alias-brand-primary)}',
      '.dsh-msg-rail-title{margin:0;font-size:15px;font-weight:600;white-space:nowrap}',
      '.dsh-msg-rail-count{font-size:11.5px;color:var(--dsw-alias-label-secondary);white-space:nowrap}',
      '.dsh-msg-rail-actions{display:flex;align-items:center;gap:6px;margin-left:auto}',
      '.dsh-msg-search{box-sizing:border-box;height:30px;width:calc(100% - 32px);margin:0 16px 8px;padding:0 10px;border:1px solid var(--dsw-alias-border-l1);border-radius:8px;background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font:inherit;font-size:12.5px;outline:none}',
      '.dsh-msg-search::placeholder{color:var(--dsw-alias-label-secondary)}',
      '.dsh-msg-search:focus{border-color:var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-2)}',
      '.dsh-msg-list{flex:1 1 auto;min-height:0;overflow-y:auto;padding:0 8px 8px}',
      '.dsh-msg-list-empty{margin:16px 8px;font-size:12px;line-height:1.6;color:var(--dsw-alias-label-secondary)}',
      '.dsh-msg-row{display:flex;align-items:center;gap:10px;width:100%;margin:0 0 2px;padding:9px 10px;border:1px solid transparent;border-radius:10px;background:transparent;color:inherit;font:inherit;text-align:left;cursor:pointer;transition:background-color .12s ease,border-color .12s ease}',
      '.dsh-msg-row:hover{background:var(--dsw-alias-bg-layer-1)}',
      '.dsh-msg-row:focus-visible{outline:2px solid var(--dsw-alias-brand-primary);outline-offset:-2px}',
      ".dsh-msg-row[data-active='true']{background:var(--dsw-alias-bg-layer-2);border-color:var(--dsw-alias-border-l1)}",
      '.dsh-msg-avatar{display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto;width:36px;height:36px;border-radius:50%;background:var(--dsw-alias-bg-layer-2);border:1px solid var(--dsw-alias-border-l1);color:var(--dsw-alias-label-primary);font-size:14px;font-weight:600}',
      '.dsh-msg-row-body{display:flex;flex-direction:column;gap:2px;flex:1 1 auto;min-width:0}',
      '.dsh-msg-row-top{display:flex;align-items:baseline;gap:8px}',
      '.dsh-msg-row-name{display:inline-flex;align-items:center;gap:5px;font-size:13px;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0;flex:1 1 auto;cursor:text}',
      '.dsh-msg-rename{display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto;color:var(--dsw-alias-label-secondary);opacity:0;transition:opacity .12s ease}',
      '.dsh-msg-row:hover .dsh-msg-rename,.dsh-msg-row:focus-within .dsh-msg-rename{opacity:1}',
      '.dsh-msg-row-time{font-size:10.5px;color:var(--dsw-alias-label-secondary);white-space:nowrap;flex:0 0 auto}',
      '.dsh-msg-row-preview{font-size:12px;color:var(--dsw-alias-label-secondary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
      '.dsh-msg-badge{display:inline-flex;align-items:center;justify-content:center;min-width:17px;height:17px;padding:0 5px;border-radius:999px;background:var(--dsw-alias-brand-primary);color:#fff;font-size:10.5px;font-weight:600;flex:0 0 auto}',
      '.dsh-msg-rail-foot{display:flex;align-items:center;gap:8px;flex:0 0 auto;padding:10px 16px;border-top:1px solid var(--dsw-alias-border-l1)}',
      '.dsh-msg-self{display:flex;flex-direction:column;min-width:0;flex:1 1 auto}',
      '.dsh-msg-self-name{font-size:12px;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
      '.dsh-msg-self-hint{font-size:10.5px;color:var(--dsw-alias-label-secondary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
      '.dsh-msg-main{display:flex;flex-direction:column;flex:1 1 auto;min-width:0;min-height:0}',
      '.dsh-msg-btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;height:30px;padding:0 12px;border:1px solid var(--dsw-alias-border-l1);border-radius:8px;background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font:inherit;font-size:12.5px;font-weight:500;cursor:pointer;white-space:nowrap;transition:background-color .15s ease,border-color .15s ease,color .15s ease}',
      '.dsh-msg-btn:hover{background:var(--dsw-alias-bg-layer-2);border-color:var(--dsw-alias-border-l2)}',
      '.dsh-msg-btn:focus-visible{outline:2px solid var(--dsw-alias-brand-primary);outline-offset:1px}',
      '.dsh-msg-btn[disabled]{opacity:.55;cursor:default}',
      '.dsh-msg-btn--primary{border-color:transparent;background:var(--dsw-alias-brand-primary);color:#fff}',
      '.dsh-msg-btn--primary:hover{background:var(--dsw-alias-brand-primary);border-color:transparent;opacity:.92}',
      '.dsh-msg-btn--ghost{border-color:transparent;background:transparent;color:var(--dsw-alias-label-secondary)}',
      '.dsh-msg-btn--ghost:hover{background:var(--dsw-alias-bg-layer-1);border-color:var(--dsw-alias-border-l1);color:var(--dsw-alias-label-primary)}',
      '.dsh-msg-btn--icon{width:30px;padding:0;position:relative}',
      '.dsh-msg-update-dot{position:absolute;top:3px;right:3px;display:block;width:6px;height:6px;border-radius:999px;background:var(--dsw-alias-state-error-primary);pointer-events:none}',
      '.dsh-msg-update-dot--icon{top:-1px;right:-2px;width:6px;height:6px}',
      '.dsh-msg-btn--code{height:28px;padding:0 10px;font-size:12px}',
      '.dsh-msg-danger:hover{color:var(--dsw-alias-state-error-primary);border-color:var(--dsw-alias-state-error-primary)}',
      ".dsh-msg-danger[data-armed='true']{color:var(--dsw-alias-state-error-primary);border-color:var(--dsw-alias-state-error-primary)}",
      '.dsh-msg-thread{display:flex;flex-direction:column;height:100%;min-height:0}',
      '.dsh-msg-thread-head{display:flex;align-items:center;gap:10px;flex:0 0 auto;padding:12px 20px;border-bottom:1px solid var(--dsw-alias-border-l1);min-height:56px;box-sizing:border-box}',
      '.dsh-msg-thread-title{display:flex;flex-direction:column;min-width:0}',
      '.dsh-msg-thread-name{margin:0;font-size:14.5px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
      '.dsh-msg-thread-status{display:flex;align-items:center;gap:6px;font-size:11.5px;color:var(--dsw-alias-label-secondary);white-space:nowrap}',
      '.dsh-msg-chip{display:inline-flex;align-items:center;height:18px;padding:0 7px;border:1px solid var(--dsw-alias-border-l1);border-radius:999px;background:var(--dsw-alias-bg-layer-1);font-size:10.5px;color:var(--dsw-alias-label-secondary);white-space:nowrap}',
      '.dsh-msg-thread-actions{display:flex;align-items:center;gap:6px;margin-left:auto}',
      '.dsh-msg-banner{display:flex;align-items:center;gap:10px;margin:10px 20px 0;padding:8px 12px;border:1px solid var(--dsw-alias-state-error-primary);border-radius:8px;font-size:12px;color:var(--dsw-alias-state-error-primary)}',
      '.dsh-msg-banner-detail{color:var(--dsw-alias-label-secondary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
      '.dsh-msg-messages{flex:1 1 auto;min-height:0;overflow-y:auto;padding:18px 24px 8px}',
      '.dsh-msg-thread-empty{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;height:100%;min-height:220px;color:var(--dsw-alias-label-secondary);padding:0 24px;text-align:center}',
      '.dsh-msg-thread-empty-art{display:inline-flex;color:var(--dsw-alias-border-l2)}',
      '.dsh-msg-thread-empty-title{margin:0;font-size:13.5px;font-weight:500;color:var(--dsw-alias-label-primary)}',
      '.dsh-msg-thread-empty-hint{margin:0;font-size:12px}',
      '.dsh-msg-message{display:flex;flex-direction:column;align-items:flex-start;gap:3px;margin-bottom:12px;max-width:100%}',
      ".dsh-msg-message[data-mine='true']{align-items:flex-end}",
      '.dsh-msg-bubble{max-width:min(560px,78%);padding:8px 12px;border:1px solid var(--dsw-alias-border-l1);border-radius:12px;background:var(--dsw-alias-bg-layer-1);white-space:pre-wrap;word-break:break-word;font-size:13px;line-height:1.55}',
      ".dsh-msg-message[data-mine='true'] .dsh-msg-bubble{background:var(--dsw-alias-bg-layer-2);border-color:var(--dsw-alias-border-l2)}",
      '.dsh-msg-meta{font-size:10.5px;color:var(--dsw-alias-label-secondary);padding:0 4px;opacity:.9}',
      ".dsh-msg-meta[data-failed='true']{color:var(--dsw-alias-state-error-primary);opacity:1}",
      '.dsh-msg-composer{display:flex;align-items:flex-end;gap:10px;flex:0 0 auto;padding:12px 24px 16px;border-top:1px solid var(--dsw-alias-border-l1)}',
      '.dsh-msg-composer-input{flex:1 1 auto;box-sizing:border-box;min-height:52px;max-height:180px;padding:8px 10px;border:1px solid var(--dsw-alias-border-l1);border-radius:10px;background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font:inherit;font-size:13px;line-height:1.55;resize:none;outline:none}',
      '.dsh-msg-composer-input:focus{border-color:var(--dsw-alias-border-l2)}',
      '.dsh-msg-composer-input::placeholder{color:var(--dsw-alias-label-secondary);opacity:.8}',
      '.dsh-msg-welcome{display:flex;flex:1 1 auto;align-items:flex-start;justify-content:center;overflow-y:auto;padding:48px 24px}',
      '.dsh-msg-card{display:flex;flex-direction:column;gap:14px;width:min(520px,100%);padding:24px;border:1px solid var(--dsw-alias-border-l1);border-radius:14px;background:var(--dsw-alias-bg-layer-1)}',
      '.dsh-msg-card-head{display:flex;align-items:center;gap:10px}',
      '.dsh-msg-card-mark{display:inline-flex;color:var(--dsw-alias-brand-primary)}',
      '.dsh-msg-card-title{margin:0;font-size:18px;font-weight:600}',
      '.dsh-msg-card-hint{margin:0;font-size:12.5px;line-height:1.65;color:var(--dsw-alias-label-secondary)}',
      '.dsh-msg-section{display:flex;flex-direction:column;gap:8px;padding:12px;border:1px solid var(--dsw-alias-border-l1);border-radius:12px}',
      '.dsh-msg-overlay{position:absolute;inset:0;z-index:30;display:flex;align-items:center;justify-content:center;padding:24px;background:rgba(0,0,0,.28)}',
      '.dsh-msg-overlay-panel{display:flex;flex-direction:column;gap:14px;width:min(680px,92vw);max-height:min(780px,88vh);overflow-y:auto;padding:20px;border:1px solid var(--dsw-alias-border-l1);border-radius:14px;background:var(--dsw-alias-bg-base);box-shadow:0 16px 48px rgba(0,0,0,.18)}',
      '.dsh-msg-overlay-head{display:flex;align-items:flex-start;gap:12px}',
      '.dsh-msg-overlay-title{margin:0;font-size:17px;font-weight:600}',
      '.dsh-msg-overlay-hint{margin:4px 0 0;font-size:12.5px;line-height:1.65;color:var(--dsw-alias-label-secondary)}',
      '.dsh-msg-close{margin-left:auto;flex:0 0 auto;display:inline-flex;align-items:center;justify-content:center;width:26px;height:26px;padding:0;border:1px solid var(--dsw-alias-border-l1);border-radius:7px;background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);cursor:pointer}',
      '.dsh-msg-close:hover{background:var(--dsw-alias-bg-layer-2)}',
      '.dsh-msg-field{display:flex;flex-direction:column;gap:6px}',
      '.dsh-msg-label{font-size:12px;font-weight:500;color:var(--dsw-alias-label-primary)}',
      '.dsh-msg-input,.dsh-msg-textarea{box-sizing:border-box;width:100%;border:1px solid var(--dsw-alias-border-l1);border-radius:8px;background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-primary);font:inherit;font-size:13px;outline:none}',
      '.dsh-msg-input{height:34px;padding:0 10px}',
      '.dsh-msg-textarea{min-height:96px;padding:8px 10px;resize:vertical;line-height:1.55}',
      '.dsh-msg-input:focus,.dsh-msg-textarea:focus{border-color:var(--dsw-alias-border-l2)}',
      '.dsh-msg-small{font-size:11.5px;line-height:1.55;color:var(--dsw-alias-label-secondary)}',
      '.dsh-msg-error{font-size:12px;color:var(--dsw-alias-state-error-primary)}',
      '.dsh-msg-row-actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap}',
      '.dsh-msg-grow{flex:1 1 auto}',
      '.dsh-msg-code{box-sizing:border-box;width:100%;min-height:170px;padding:10px;border:1px solid var(--dsw-alias-border-l1);border-radius:8px;background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px;line-height:1.6;resize:vertical;outline:none}',
      '.dsh-msg-code:focus{border-color:var(--dsw-alias-border-l2)}',
      '.dsh-msg-divider{height:1px;background:var(--dsw-alias-border-l1);margin:2px 0}',
    ].join('\n');

    /* ------------------------------------------------------------------ *
     * Panel
     * ------------------------------------------------------------------ */

    function ContactsPanel(props) {
      const t = props.t;
      const lang = activeLang(props.locale);

      const [state, setState] = React.useState(null);
      const [threads, setThreads] = React.useState({});
      const [unread, setUnread] = React.useState({});
      const [loadError, setLoadError] = React.useState('');
      const [threadError, setThreadError] = React.useState('');
      const [reloadKey, setReloadKey] = React.useState(0);
      const [streamEpoch, setStreamEpoch] = React.useState(0);
      const [threadReload, setThreadReload] = React.useState(0);
      const [draft, setDraft] = React.useState('');
      const [sendError, setSendError] = React.useState('');
      const [search, setSearch] = React.useState('');
      const [overlay, setOverlay] = React.useState(null);
      const [addCodeInput, setAddCodeInput] = React.useState('');
      const [addBusy, setAddBusy] = React.useState(false);
      const [formError, setFormError] = React.useState('');
      const [copied, setCopied] = React.useState('');
      const [renameDraft, setRenameDraft] = React.useState('');
      const [clearArmed, setClearArmed] = React.useState(false);
      const [removeArmed, setRemoveArmed] = React.useState(false);
      const [settingsNick, setSettingsNick] = React.useState('');
      const [settingsRelay, setSettingsRelay] = React.useState(DEFAULT_RELAY);
      const [updateSpec, setUpdateSpec] = React.useState('');
      const [updateBusy, setUpdateBusy] = React.useState(false);
      const [updateNotice, setUpdateNotice] = React.useState('');
      const messageListRef = React.useRef(null);
      const copyTimer = React.useRef(null);
      const threadToken = React.useRef(0);
      const stateRef = React.useRef(null);
      const threadsRef = React.useRef({});
      const loadedRef = React.useRef(new Set());

      const applyState = React.useCallback((next) => {
        if (!next || typeof next !== 'object') return;
        if (!next.self || !Array.isArray(next.contacts)) return;
        publishUpdateWatch(next);
        setState((previous) => {
          if (!previous || !Array.isArray(previous.contacts)) return next;
          // An incoming null preview is authoritative (history was cleared);
          // only a *newer* non-null preview wins over the local one.
          const byId = new Map();
          for (const entry of previous.contacts) byId.set(entry.id, entry);
          const contacts = next.contacts.map((entry) => {
            const old = byId.get(entry.id);
            if (!old || !entry.lastMessage || !old.lastMessage) return entry;
            return old.lastMessage.at > entry.lastMessage.at
              ? Object.assign({}, entry, { lastMessage: old.lastMessage })
              : entry;
          });
          return Object.assign({}, next, { contacts });
        });
        const live = new Set(next.contacts.map((contact) => contact.id));
        for (const id of Array.from(loadedRef.current)) {
          if (!live.has(id)) loadedRef.current.delete(id);
        }
        setLoadError('');
      }, []);

      const post = React.useCallback(
        async (path, body) => {
          try {
            const response = await fetch(API + path, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(body || {}),
            });
            const payload = await response.json().catch(() => null);
            if (payload && payload.state) applyState(payload.state);
            return payload || { ok: false, error: 'network' };
          } catch (err) {
            return { ok: false, error: 'network' };
          }
        },
        [applyState],
      );

      // Bootstrap: one snapshot, then the live stream.
      React.useEffect(() => {
        // Look for a new version as soon as the panel opens, so the red dot
        // does not wait for the half-hourly round.
        void post('/update/check', {}).catch(() => undefined);
        let disposed = false;
        let source = null;
        fetch(API + '/state', { headers: { Accept: 'application/json' }, cache: 'no-store' })
          .then((response) => response.json())
          .then((payload) => {
            if (disposed) return;
            if (payload && payload.ok && payload.state) applyState(payload.state);
            else throw new Error('bad-state');
          })
          .catch(() => {
            if (!disposed) setLoadError(t('loadError'));
          });
        if (typeof window.EventSource === 'function') {
          try {
            source = new window.EventSource(API + '/events');
            source.addEventListener('hello', () => {
              // A fresh stream means we may have missed messages: forget the
              // "history loaded" marks and let the loader refetch.
              loadedRef.current = new Set();
              setStreamEpoch((value) => value + 1);
            });
            source.addEventListener('state', (event) => {
              try {
                applyState(JSON.parse(event.data));
              } catch (err) {
                /* ignore a torn frame; the next snapshot is complete */
              }
            });
            source.addEventListener('contact', (event) => {
              try {
                const contact = JSON.parse(event.data);
                if (!contact || typeof contact.id !== 'string') return;
                setState((previous) => {
                  if (!previous || !Array.isArray(previous.contacts)) return previous;
                  const contacts = previous.contacts.map((entry) => {
                    if (entry.id !== contact.id) return entry;
                    if (!entry.lastMessage || !contact.lastMessage) return contact;
                    return entry.lastMessage.at > contact.lastMessage.at
                      ? Object.assign({}, contact, { lastMessage: entry.lastMessage })
                      : contact;
                  });
                  return Object.assign({}, previous, { contacts });
                });
              } catch (err) {
                /* ignore */
              }
            });
            source.addEventListener('message', (event) => {
              try {
                const payload = JSON.parse(event.data);
                if (!payload || typeof payload.contactId !== 'string') return;
                const message = payload.message;
                if (
                  !message ||
                  typeof message.id !== 'string' ||
                  typeof message.text !== 'string'
                ) {
                  return;
                }
                setThreads((previous) => ({
                  ...previous,
                  [payload.contactId]: upsertMessage(previous[payload.contactId], message),
                }));
                const active = stateRef.current ? stateRef.current.activeId : '';
                // Own sends are not "unread", and neither is the open chat.
                if (!message.mine && payload.contactId !== active) {
                  setUnread((previous) => ({
                    ...previous,
                    [payload.contactId]: (previous[payload.contactId] || 0) + 1,
                  }));
                }
              } catch (err) {
                /* ignore */
              }
            });
            source.addEventListener('thread', (event) => {
              try {
                const payload = JSON.parse(event.data);
                if (!payload || typeof payload.contactId !== 'string') return;
                if (!Array.isArray(payload.messages)) return;
                setThreads((previous) => ({
                  ...previous,
                  [payload.contactId]: payload.messages,
                }));
                loadedRef.current.add(payload.contactId);
              } catch (err) {
                /* ignore */
              }
            });
          } catch (err) {
            /* the initial snapshot reports connectivity problems */
          }
        }
        return () => {
          disposed = true;
          if (source) source.close();
        };
      }, [applyState, t, reloadKey]);

      const activeId = state ? state.activeId || '' : '';
      const activeContact = state
        ? state.contacts.find((contact) => contact.id === activeId) || null
        : null;
      const messages = threads[activeId] || [];
      const status = state ? state.status || 'idle' : 'idle';

      React.useEffect(() => {
        stateRef.current = state;
      }, [state]);
      React.useEffect(() => {
        threadsRef.current = threads;
      }, [threads]);

      // Load a conversation's stored history the first time it is opened, and
      // again whenever the page stream restarted or the user asked to retry.
      React.useEffect(() => {
        if (!activeId) {
          setThreadError('');
          return undefined;
        }
        if (loadedRef.current.has(activeId)) return undefined;
        const token = ++threadToken.current;
        let cancelled = false;
        setThreadError('');
        fetch(API + '/thread?id=' + encodeURIComponent(activeId), { cache: 'no-store' })
          .then((response) => response.json())
          .then((payload) => {
            if (cancelled || token !== threadToken.current) return;
            if (!payload || !payload.ok || !Array.isArray(payload.messages)) {
              setThreadError(t('threadLoadError'));
              return;
            }
            const fetched = payload.messages;
            setThreads((previous) => {
              const seeded = Array.isArray(previous[activeId]) ? previous[activeId] : [];
              const byId = new Map();
              for (const entry of fetched) byId.set(entry.id, entry);
              for (const entry of seeded) {
                const existing = byId.get(entry.id);
                if (!existing) {
                  byId.set(entry.id, entry);
                  continue;
                }
                // pending only ever clears, so the non-pending copy is newer.
                if (existing.pending && !entry.pending) byId.set(entry.id, entry);
              }
              const merged = Array.from(byId.values()).sort(
                (left, right) => (left.at || 0) - (right.at || 0),
              );
              if (merged.length > 400) merged.splice(0, merged.length - 400);
              return { ...previous, [activeId]: merged };
            });
            loadedRef.current.add(activeId);
            setThreadError('');
          })
          .catch(() => {
            if (!cancelled && token === threadToken.current) setThreadError(t('threadLoadError'));
          });
        return () => {
          cancelled = true;
        };
      }, [activeId, streamEpoch, threadReload, t]);

      // Opening a conversation clears its badge.
      React.useEffect(() => {
        if (!activeId) return;
        setUnread((previous) => (previous[activeId] ? { ...previous, [activeId]: 0 } : previous));
      }, [activeId]);

      const messageCount = messages.length;
      React.useEffect(() => {
        const element = messageListRef.current;
        if (!element) return;
        element.scrollTop = element.scrollHeight;
      }, [activeId, messageCount]);

      React.useEffect(
        () => () => {
          if (copyTimer.current) clearTimeout(copyTimer.current);
        },
        [],
      );

      const copyText = React.useCallback((text, key) => {
        const done = () => {
          setCopied(key);
          if (copyTimer.current) clearTimeout(copyTimer.current);
          copyTimer.current = setTimeout(() => setCopied(''), 1800);
        };
        try {
          if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
            navigator.clipboard.writeText(text).then(done).catch(() => {});
            return;
          }
        } catch (err) {
          /* fall through to the manual selection path */
        }
        try {
          const area = document.createElement('textarea');
          area.value = text;
          document.body.appendChild(area);
          area.select();
          document.execCommand('copy');
          document.body.removeChild(area);
          done();
        } catch (err) {
          /* clipboard unavailable; the text stays selectable */
        }
      }, []);

      const openContact = React.useCallback(
        async (contactId) => {
          if (contactId === activeId) return;
          const result = await post('/active', { id: contactId });
          if (!result.ok) {
            setSendError(result.detail || t('loadError'));
            return;
          }
          setDraft('');
          setSendError('');
        },
        [activeId, post, t],
      );

      const handleSend = async () => {
        const text = draft.trim();
        const targetId = activeId;
        if (!text || !targetId) return;
        if (text.length > MAX_TEXT) {
          setSendError(t('failed'));
          return;
        }
        setDraft('');
        setSendError('');
        const result = await post('/send', { id: targetId, text });
        if (result.ok) return;
        // Only restore into the same conversation, and never overwrite text the
        // user typed while the send was in flight.
        const stillHere = stateRef.current && stateRef.current.activeId === targetId;
        if (!stillHere) return;
        setDraft((previous) => (previous ? previous : text));
        setSendError(t('failed') + (result.detail ? ' · ' + result.detail : ''));
      };

      const handleAdd = async () => {
        setFormError('');
        const code = addCodeInput.trim();
        if (!code) return;
        setAddBusy(true);
        const result = await post('/contacts', { code });
        setAddBusy(false);
        if (!result.ok) {
          const known = {
            'invalid-code': t('badCard'),
            'own-code': t('ownCode'),
            'too-many-contacts': t('tooMany'),
          };
          setFormError(known[result.error] || result.detail || t('loadError'));
          return;
        }
        setAddCodeInput('');
        setOverlay(null);
      };

      const openInfo = (contact) => {
        setRenameDraft(contact.name || '');
        setClearArmed(false);
        setRemoveArmed(false);
        setFormError('');
        setCopied('');
        setOverlay({ kind: 'info', contactId: contact.id });
      };

      const handleSaveSettings = async () => {
        setFormError('');
        const name = settingsNick.trim();
        if (!name) {
          setFormError(t('needName'));
          return;
        }
        if (!normalizeRelay(settingsRelay)) {
          setFormError(t('badRelay'));
          return;
        }
        const result = await post('/self', { nick: name, relay: settingsRelay });
        if (result.ok) setOverlay(null);
        else setFormError(result.detail || t('loadError'));
      };

      /* -------------------------------------------------------------- *
       * Render helpers
       * -------------------------------------------------------------- */

      const renderAvatar = (contact) =>
        h('span', { className: 'dsh-msg-avatar' }, initial(contact.name || ''));

      const renderOverlay = () => {
        if (!overlay) return null;

        if (overlay.kind === 'add') {
          return h(
            'div',
            {
              className: 'dsh-msg-overlay',
              role: 'dialog',
              'aria-modal': 'true',
              'aria-label': t('addTitle'),
              onClick: () => setOverlay(null),
            },
            h(
              'div',
              { className: 'dsh-msg-overlay-panel', onClick: (event) => event.stopPropagation() },
              h(
                'div',
                { className: 'dsh-msg-overlay-head' },
                h(
                  'div',
                  null,
                  h('h2', { className: 'dsh-msg-overlay-title' }, t('addTitle')),
                  h('p', { className: 'dsh-msg-overlay-hint' }, t('addHint')),
                ),
                h(
                  'button',
                  {
                    type: 'button',
                    className: 'dsh-msg-close',
                    title: t('close'),
                    'aria-label': t('close'),
                    onClick: () => setOverlay(null),
                  },
                  closeGlyph(13),
                ),
              ),
              h(
                'label',
                { className: 'dsh-msg-field' },
                h('span', { className: 'dsh-msg-label' }, t('addCodeLabel')),
                h('textarea', {
                  className: 'dsh-msg-textarea',
                  spellCheck: false,
                  value: addCodeInput,
                  placeholder: t('addCodePlaceholder'),
                  onChange: (event) => setAddCodeInput(event.target.value),
                }),
              ),
              formError ? h('div', { className: 'dsh-msg-error' }, formError) : null,
              h(
                'div',
                { className: 'dsh-msg-row-actions' },
                h('span', { className: 'dsh-msg-grow' }),
                h(
                  'button',
                  {
                    type: 'button',
                    className: 'dsh-msg-btn dsh-msg-btn--ghost',
                    onClick: () => setOverlay(null),
                  },
                  t('cancel'),
                ),
                h(
                  'button',
                  {
                    type: 'button',
                    className: 'dsh-msg-btn dsh-msg-btn--primary',
                    disabled: addBusy || !addCodeInput.trim(),
                    onClick: () => void handleAdd(),
                  },
                  t('addButton'),
                ),
              ),
            ),
          );
        }

        if (overlay.kind === 'mycard') {
          const code = state ? state.addCode || '' : '';
          const cardText = buildCardText(lang, {
            name: state ? state.self.nick : '',
            code,
          });
          return h(
            'div',
            {
              className: 'dsh-msg-overlay',
              role: 'dialog',
              'aria-modal': 'true',
              'aria-label': t('myCodeTitle'),
              onClick: () => setOverlay(null),
            },
            h(
              'div',
              { className: 'dsh-msg-overlay-panel', onClick: (event) => event.stopPropagation() },
              h(
                'div',
                { className: 'dsh-msg-overlay-head' },
                h(
                  'div',
                  null,
                  h('h2', { className: 'dsh-msg-overlay-title' }, t('myCodeTitle')),
                  h('p', { className: 'dsh-msg-overlay-hint' }, t('myCodeHint')),
                ),
                h(
                  'button',
                  {
                    type: 'button',
                    className: 'dsh-msg-close',
                    title: t('close'),
                    'aria-label': t('close'),
                    onClick: () => setOverlay(null),
                  },
                  closeGlyph(13),
                ),
              ),
              h('textarea', {
                className: 'dsh-msg-code',
                readOnly: true,
                spellCheck: false,
                value: cardText,
                onFocus: (event) => event.target.select(),
              }),
              h(
                'div',
                { className: 'dsh-msg-row-actions' },
                h(
                  'button',
                  {
                    type: 'button',
                    className: 'dsh-msg-btn dsh-msg-btn--ghost',
                    onClick: () => copyText(code, 'code'),
                  },
                  copyGlyph(13),
                  h('span', null, copied === 'code' ? t('copied') : t('copyCode')),
                ),
                h(
                  'button',
                  {
                    type: 'button',
                    className: 'dsh-msg-btn dsh-msg-btn--primary',
                    onClick: () => copyText(cardText, 'card'),
                  },
                  copyGlyph(13),
                  h('span', null, copied === 'card' ? t('copied') : t('copyCard')),
                ),
              ),
            ),
          );
        }

        const handleSaveUpdateSource = async () => {
          const spec = updateSpec.trim();
          if (spec && !/^(@[a-z0-9][a-z0-9._-]*\/)?[a-z0-9][a-z0-9._-]*(@[a-z0-9][a-z0-9._^~<>=*-]*)?$/i.test(spec)) {
            setUpdateNotice(t('updateBadSource'));
            return;
          }
          setUpdateBusy(true);
          const result = await post('/update/source', { spec });
          setUpdateBusy(false);
          if (!result.ok) {
            setUpdateNotice(t('updateFailed'));
            return;
          }
          setUpdateNotice(t('updateSourceSaved'));
        };

        const handleCheckUpdate = async () => {
          if (!updateSpec.trim()) {
            setUpdateNotice(t('updateNeedSource'));
            return;
          }
          setUpdateBusy(true);
          setUpdateNotice(t('updateChecking'));
          const result = await post('/update/check', { force: true });
          setUpdateBusy(false);
          if (!result.ok) {
            setUpdateNotice(updateErrorText(result.error));
            return;
          }
          const update = result.state && result.state.update;
          setUpdateNotice(update && update.available ? t('updateAvailable') + ' ' + update.latest : t('updateUpToDate'));
        };

        const updateErrorText = (error) => {
          if (error === 'not-a-bundle') return t('updateNotBundle');
          if (error === 'spec-mismatch') return t('updateMismatch');
          if (error === 'not-found') return t('updateNotPublished');
          if (error === 'fake-update') return t('updateFake');
          if (error === 'no-plugin-manager') return t('updateNoManager');
          if (error === 'busy') return t('updateBusy');
          if (error === 'manifest-failed') return t('updateManifestFailed');
          if (error === 'download-failed') return t('updateDownloadFailed');
          return t('updateFailed') + (error ? '（' + error + '）' : '');
        };

        const handleInstallUpdate = async () => {
          setUpdateBusy(true);
          setUpdateNotice(t('updateInstalling'));
          const result = await post('/update/install', {});
          setUpdateBusy(false);
          if (!result.ok) {
            setUpdateNotice(updateErrorText(result.error));
            return;
          }
          setUpdateNotice(
            result.application === 'simulated' ? t('updateSimulated') : t('updateUpToDate'),
          );
        };

        if (overlay.kind === 'settings') {
          return h(
            'div',
            {
              className: 'dsh-msg-overlay',
              role: 'dialog',
              'aria-modal': 'true',
              'aria-label': t('settingsTitle'),
              onClick: () => setOverlay(null),
            },
            h(
              'div',
              { className: 'dsh-msg-overlay-panel', onClick: (event) => event.stopPropagation() },
              h(
                'div',
                { className: 'dsh-msg-overlay-head' },
                h(
                  'div',
                  null,
                  h('h2', { className: 'dsh-msg-overlay-title' }, t('settingsTitle')),
                  h('p', { className: 'dsh-msg-overlay-hint' }, t('limitsHint')),
                ),
                h(
                  'button',
                  {
                    type: 'button',
                    className: 'dsh-msg-close',
                    title: t('close'),
                    'aria-label': t('close'),
                    onClick: () => setOverlay(null),
                  },
                  closeGlyph(13),
                ),
              ),
              h(
                'label',
                { className: 'dsh-msg-field' },
                h('span', { className: 'dsh-msg-label' }, t('myName')),
                h('input', {
                  className: 'dsh-msg-input',
                  type: 'text',
                  maxLength: 40,
                  value: settingsNick,
                  onChange: (event) => setSettingsNick(event.target.value),
                }),
              ),
              h(
                'label',
                { className: 'dsh-msg-field' },
                h('span', { className: 'dsh-msg-label' }, t('defaultRelay')),
                h('input', {
                  className: 'dsh-msg-input',
                  type: 'url',
                  spellCheck: false,
                  value: settingsRelay,
                  onChange: (event) => setSettingsRelay(event.target.value),
                }),
                h('span', { className: 'dsh-msg-small' }, t('relayHint')),
              ),
              h(
                'div',
                { className: 'dsh-msg-section' },
                h('span', { className: 'dsh-msg-label' }, t('updateTitle')),
                h(
                  'span',
                  { className: 'dsh-msg-small' },
                  t('updateVersion') + ' ' + ((state && state.update && state.update.current) || '1.4.0'),
                ),
                h(
                  'label',
                  { className: 'dsh-msg-field' },
                  h('span', { className: 'dsh-msg-label' }, t('updateSource')),
                  h('input', {
                    className: 'dsh-msg-input',
                    type: 'text',
                    spellCheck: false,
                    placeholder: 'dsh-chat-room 或 https://…/release.json',
                    value: updateSpec,
                    onChange: (event) => setUpdateSpec(event.target.value),
                  }),
                  h('span', { className: 'dsh-msg-small' }, t('updateSourceHint')),
                ),
                h(
                  'div',
                  { className: 'dsh-msg-row-actions' },
                  h(
                    'button',
                    {
                      type: 'button',
                      className: 'dsh-msg-btn',
                      disabled: updateBusy,
                      onClick: () => void handleSaveUpdateSource(),
                    },
                    t('updateSave'),
                  ),
                  h(
                    'button',
                    {
                      type: 'button',
                      className: 'dsh-msg-btn',
                      disabled: updateBusy,
                      onClick: () => void handleCheckUpdate(),
                    },
                    t('updateCheck'),
                  ),
                  state && state.update && state.update.available
                    ? h(
                        'button',
                        {
                          type: 'button',
                          className: 'dsh-msg-btn dsh-msg-btn--primary',
                          disabled: updateBusy,
                          onClick: () => void handleInstallUpdate(),
                        },
                        t('updateInstall'),
                      )
                    : null,
                  h('span', { className: 'dsh-msg-grow' }),
                ),
                state && state.update && state.update.available
                  ? h(
                      'span',
                      { className: 'dsh-msg-small' },
                      t('updateAvailable') + ' ' + state.update.latest,
                    )
                  : null,
                updateNotice ? h('span', { className: 'dsh-msg-small' }, updateNotice) : null,
              ),
              formError ? h('div', { className: 'dsh-msg-error' }, formError) : null,
              h(
                'div',
                { className: 'dsh-msg-row-actions' },
                h('span', { className: 'dsh-msg-grow' }),
                h(
                  'button',
                  {
                    type: 'button',
                    className: 'dsh-msg-btn dsh-msg-btn--primary',
                    onClick: () => void handleSaveSettings(),
                  },
                  t('save'),
                ),
              ),
            ),
          );
        }

        // Contact info: rename, clear history, remove.
        const contact = state
          ? state.contacts.find((entry) => entry.id === overlay.contactId) || null
          : null;
        if (!contact) return null;
        return h(
          'div',
          {
            className: 'dsh-msg-overlay',
            role: 'dialog',
            'aria-modal': 'true',
            'aria-label': t('contactInfo'),
            onClick: () => setOverlay(null),
          },
          h(
            'div',
            { className: 'dsh-msg-overlay-panel', onClick: (event) => event.stopPropagation() },
            h(
              'div',
              { className: 'dsh-msg-overlay-head' },
              h(
                'div',
                null,
                h('h2', { className: 'dsh-msg-overlay-title' }, t('contactInfo')),
                h(
                  'p',
                  { className: 'dsh-msg-overlay-hint' },
                  contact.name || t('unnamed'),
                ),
                contact.auto
                  ? h('p', { className: 'dsh-msg-small' }, t('autoAddedInfo'))
                  : null,
              ),
              h(
                'button',
                {
                  type: 'button',
                  className: 'dsh-msg-close',
                  title: t('close'),
                  'aria-label': t('close'),
                  onClick: () => setOverlay(null),
                },
                closeGlyph(13),
              ),
            ),
            h(
              'label',
              { className: 'dsh-msg-field' },
              h('span', { className: 'dsh-msg-label' }, t('renameLabel')),
              h('input', {
                className: 'dsh-msg-input',
                type: 'text',
                maxLength: 40,
                value: renameDraft,
                placeholder: t('namePlaceholder'),
                onChange: (event) => setRenameDraft(event.target.value),
              }),
            ),
            formError ? h('div', { className: 'dsh-msg-error' }, formError) : null,
            h('div', { className: 'dsh-msg-divider' }),
            h(
              'div',
              { className: 'dsh-msg-row-actions' },
              h(
                'button',
                {
                  type: 'button',
                  className: 'dsh-msg-btn dsh-msg-danger',
                  'data-armed': clearArmed ? 'true' : 'false',
                  onClick: async () => {
                    if (!clearArmed) {
                      setClearArmed(true);
                      return;
                    }
                    setClearArmed(false);
                    const result = await post('/clear', { id: contact.id });
                    if (!result.ok) setFormError(result.detail || t('loadError'));
                  },
                },
                clearArmed ? t('clearConfirm') : t('clear'),
              ),
              h(
                'button',
                {
                  type: 'button',
                  className: 'dsh-msg-btn dsh-msg-danger',
                  'data-armed': removeArmed ? 'true' : 'false',
                  onClick: async () => {
                    if (!removeArmed) {
                      setRemoveArmed(true);
                      return;
                    }
                    setRemoveArmed(false);
                    const result = await post('/contacts/remove', { id: contact.id });
                    if (result.ok) setOverlay(null);
                    else setFormError(result.detail || t('loadError'));
                  },
                },
                removeArmed ? t('removeConfirm') : t('remove'),
              ),
              h('span', { className: 'dsh-msg-grow' }),
              h(
                'button',
                {
                  type: 'button',
                  className: 'dsh-msg-btn dsh-msg-btn--primary',
                  onClick: async () => {
                    const name = renameDraft.trim();
                    if (!name) {
                      setFormError(t('needName'));
                      return;
                    }
                    const result = await post('/contacts/rename', { id: contact.id, name });
                    if (!result.ok) {
                      setFormError(result.detail || t('loadError'));
                      return;
                    }
                    setFormError('');
                    setOverlay(null);
                  },
                },
                t('save'),
              ),
            ),
          ),
        );
      };

      /* -------------------------------------------------------------- *
       * Render: shell
       * -------------------------------------------------------------- */

      const contacts = state ? sortContacts(state.contacts) : [];
      const visible = contacts.filter((contact) => {
        if (!search.trim()) return true;
        const query = search.trim().toLowerCase();
        const preview = contact.lastMessage ? contact.lastMessage.text : '';
        return (
          (contact.name || '').toLowerCase().indexOf(query) >= 0 ||
          preview.toLowerCase().indexOf(query) >= 0
        );
      });

      const openAdd = () => {
        setAddCodeInput('');
        setFormError('');
        setOverlay({ kind: 'add' });
      };
      const openMyCode = () => {
        setCopied('');
        setOverlay({ kind: 'mycard' });
      };

      const rail = h(
        'aside',
        { className: 'dsh-msg-rail', 'aria-label': t('title') },
        h(
          'div',
          { className: 'dsh-msg-rail-head' },
          h('span', { className: 'dsh-msg-rail-mark' }, contactsGlyph(17)),
          h('h1', { className: 'dsh-msg-rail-title' }, t('title')),
          state
            ? h(
                'span',
                { className: 'dsh-msg-rail-count' },
                contacts.length + ' ' + t('contactCount'),
              )
            : null,
          h(
            'div',
            { className: 'dsh-msg-rail-actions' },
            h(
              'button',
              {
                type: 'button',
                className: 'dsh-msg-btn dsh-msg-btn--icon',
                title: t('addContact'),
                'aria-label': t('addContact'),
                onClick: openAdd,
              },
              plusGlyph(14),
            ),
          ),
        ),
        contacts.length
          ? h('input', {
              className: 'dsh-msg-search',
              type: 'search',
              value: search,
              placeholder: t('searchPlaceholder'),
              'aria-label': t('searchPlaceholder'),
              onChange: (event) => setSearch(event.target.value),
            })
          : null,
        h(
          'div',
          { className: 'dsh-msg-list' },
          visible.length
            ? visible.map((contact) =>
                h(
                  'button',
                  {
                    key: contact.id,
                    type: 'button',
                    className: 'dsh-msg-row',
                    'data-active': contact.id === activeId ? 'true' : 'false',
                    'aria-current': contact.id === activeId ? 'true' : undefined,
                    onClick: () => void openContact(contact.id),
                  },
                  renderAvatar(contact),
                  h(
                    'span',
                    { className: 'dsh-msg-row-body' },
                    h(
                      'span',
                      { className: 'dsh-msg-row-top' },
                      h(
                        'span',
                        {
                          className: 'dsh-msg-row-name',
                          title: t('renameHint'),
                          onClick: (event) => {
                            event.stopPropagation();
                            openInfo(contact);
                          },
                        },
                        contact.name || t('unnamed'),
                        h(
                          'span',
                          { className: 'dsh-msg-rename', 'aria-hidden': true },
                          pencilGlyph(12),
                        ),
                      ),
                      h(
                        'span',
                        { className: 'dsh-msg-row-time' },
                        contact.lastMessage ? shortTime(contact.lastMessage.at) : '',
                      ),
                    ),
                    h(
                      'span',
                      { className: 'dsh-msg-row-preview' },
                      contact.lastMessage
                        ? (contact.lastMessage.mine ? t('you') + ': ' : '') +
                          contact.lastMessage.text
                        : contact.via === 'ping'
                          ? t('addedYou')
                          : contact.auto
                            ? t('autoAdded')
                            : t('waitingPeer'),
                    ),
                  ),
                  unread[contact.id]
                    ? h('span', { className: 'dsh-msg-badge' }, String(unread[contact.id]))
                    : contact.auto && !contact.lastMessage
                      ? h('span', { className: 'dsh-msg-badge' }, t('newBadge'))
                      : null,
                ),
              )
            : h(
                'p',
                { className: 'dsh-msg-list-empty' },
                contacts.length ? t('searchPlaceholder') : t('noContactsHint'),
              ),
        ),
        state
          ? h(
              'div',
              { className: 'dsh-msg-rail-foot' },
              h(
                'div',
                { className: 'dsh-msg-self' },
                h('span', { className: 'dsh-msg-self-name' }, state.self.nick || t('you')),
                h(
                  'span',
                  { className: 'dsh-msg-self-hint' },
                  state.self.unnamed ? t('setYourName') : statusLabel(status, t),
                ),
              ),
              h(
                'button',
                {
                  type: 'button',
                  className: 'dsh-msg-btn dsh-msg-btn--code',
                  title: t('myCodeTitle'),
                  onClick: openMyCode,
                },
                t('myCodeShort'),
              ),
              h(
                'button',
                {
                  type: 'button',
                  className: 'dsh-msg-btn dsh-msg-btn--icon',
                  title: state.update && state.update.available
                    ? t('updateAvailable') + ' ' + state.update.latest
                    : t('settingsTitle'),
                  'aria-label': t('settingsTitle'),
                  onClick: () => {
                    setSettingsNick(state.self.nick || '');
                    setSettingsRelay(state.relay || DEFAULT_RELAY);
                    setUpdateSpec((state.update && state.update.spec) || '');
                    setUpdateNotice('');
                    setFormError('');
                    setOverlay({ kind: 'settings' });
                  },
                },
                gearGlyph(16),
                state.update && state.update.available ? updateDot() : null,
              ),
            )
          : null,
      );

      let main;
      if (!state) {
        main = h(
          'div',
          { className: 'dsh-msg-welcome' },
          h(
            'div',
            { className: 'dsh-msg-card' },
            h(
              'div',
              { className: 'dsh-msg-card-head' },
              h('span', { className: 'dsh-msg-card-mark' }, contactsGlyph(22)),
              h('h1', { className: 'dsh-msg-card-title' }, t('title')),
            ),
            h('p', { className: 'dsh-msg-card-hint' }, loadError || '…'),
            loadError
              ? h(
                  'div',
                  { className: 'dsh-msg-row-actions' },
                  h(
                    'button',
                    {
                      type: 'button',
                      className: 'dsh-msg-btn dsh-msg-btn--primary',
                      onClick: () => {
                        setLoadError('');
                        setReloadKey((value) => value + 1);
                      },
                    },
                    t('retry'),
                  ),
                )
              : null,
          ),
        );
      } else if (!state.contacts.length) {
        main = h(
          'div',
          { className: 'dsh-msg-welcome' },
          h(
            'div',
            { className: 'dsh-msg-card' },
            h(
              'div',
              { className: 'dsh-msg-card-head' },
              h('span', { className: 'dsh-msg-card-mark' }, contactsGlyph(22)),
              h('h1', { className: 'dsh-msg-card-title' }, t('noContactsTitle')),
            ),
            h('p', { className: 'dsh-msg-card-hint' }, t('noContactsHint')),
            h(
              'div',
              { className: 'dsh-msg-row-actions' },
              h(
                'button',
                {
                  type: 'button',
                  className: 'dsh-msg-btn dsh-msg-btn--primary',
                  onClick: openAdd,
                },
                t('addContact'),
              ),
              h(
                'button',
                { type: 'button', className: 'dsh-msg-btn', onClick: openMyCode },
                t('myCode'),
              ),
            ),
          ),
        );
      } else if (!activeContact) {
        main = h(
          'div',
          { className: 'dsh-msg-welcome' },
          h(
            'div',
            { className: 'dsh-msg-card' },
            h(
              'div',
              { className: 'dsh-msg-card-head' },
              h('span', { className: 'dsh-msg-card-mark' }, contactsGlyph(22)),
              h('h1', { className: 'dsh-msg-card-title' }, t('selectContact')),
            ),
            h('p', { className: 'dsh-msg-card-hint' }, t('selectContactHint')),
            h(
              'div',
              { className: 'dsh-msg-row-actions' },
              h(
                'button',
                { type: 'button', className: 'dsh-msg-btn dsh-msg-btn--primary', onClick: openAdd },
                t('addContact'),
              ),
              h(
                'button',
                { type: 'button', className: 'dsh-msg-btn', onClick: openMyCode },
                t('myCode'),
              ),
            ),
          ),
        );
      } else {
        const threadMessages = messages;
        main = h(
          'section',
          { className: 'dsh-msg-thread', 'aria-label': activeContact.name || t('unnamed') },
          h(
            'header',
            { className: 'dsh-msg-thread-head' },
            renderAvatar(activeContact),
            h(
              'div',
              { className: 'dsh-msg-thread-title' },
              h('h2', { className: 'dsh-msg-thread-name' }, activeContact.name || t('unnamed')),
              h(
                'span',
                { className: 'dsh-msg-thread-status' },
                statusLabel(status, t),
                activeContact.short
                  ? h('span', { className: 'dsh-msg-chip' }, '#' + activeContact.short)
                  : null,
                activeContact.unnamed
                  ? h('span', { className: 'dsh-msg-chip' }, t('noNameYet'))
                  : null,
                activeContact.via === 'ping' && messages.length === 0
                  ? h('span', { className: 'dsh-msg-chip' }, t('addedYou'))
                  : null,
              ),
            ),
            h(
              'div',
              { className: 'dsh-msg-thread-actions' },
              h(
                'button',
                {
                  type: 'button',
                  className: 'dsh-msg-btn',
                  onClick: () => openInfo(activeContact),
                },
                t('info'),
              ),
            ),
          ),
          status === 'error' && state.error
            ? h(
                'div',
                { className: 'dsh-msg-banner' },
                h('span', null, t('relayError')),
                h('span', { className: 'dsh-msg-banner-detail' }, state.error),
              )
            : null,
          threadError
            ? h(
                'div',
                { className: 'dsh-msg-banner' },
                h('span', null, threadError),
                h('span', { className: 'dsh-msg-grow' }),
                h(
                  'button',
                  {
                    type: 'button',
                    className: 'dsh-msg-btn dsh-msg-btn--ghost',
                    onClick: () => {
                      loadedRef.current.delete(activeId);
                      setThreadError('');
                      setThreadReload((value) => value + 1);
                    },
                  },
                  t('retry'),
                ),
              )
            : null,
          h(
            'div',
            { className: 'dsh-msg-messages', ref: messageListRef },
            threadMessages.length === 0
              ? h(
                  'div',
                  { className: 'dsh-msg-thread-empty' },
                  h('div', { className: 'dsh-msg-thread-empty-art' }, contactsGlyph(40)),
                  h('p', { className: 'dsh-msg-thread-empty-title' }, t('noMessages')),
                  h('p', { className: 'dsh-msg-thread-empty-hint' }, t('noMessagesHint')),
                )
              : threadMessages.map((message) =>
                  h(
                    'div',
                    {
                      key: message.id,
                      className: 'dsh-msg-message',
                      'data-mine': message.mine ? 'true' : 'false',
                    },
                    h('div', { className: 'dsh-msg-bubble' }, message.text),
                    h(
                      'div',
                      {
                        className: 'dsh-msg-meta',
                        'data-failed': message.failed ? 'true' : 'false',
                      },
                      formatTime(message.at) +
                        (message.mine ? ' · ' + t('you') : '') +
                        (message.pending ? ' · ' + t('sending') : '') +
                        (message.failed ? ' · ' + t('failed') : ''),
                    ),
                  ),
                ),
          ),
          sendError ? h('div', { className: 'dsh-msg-banner' }, h('span', null, sendError)) : null,
          h(
            'div',
            { className: 'dsh-msg-composer' },
            h('textarea', {
              className: 'dsh-msg-composer-input',
              value: draft,
              maxLength: MAX_TEXT,
              placeholder: t('composerPlaceholder'),
              'aria-label': t('composerPlaceholder'),
              onChange: (event) => setDraft(event.target.value),
              onKeyDown: (event) => {
                if (event.key === 'Enter' && !event.shiftKey && !event.nativeEvent.isComposing) {
                  event.preventDefault();
                  void handleSend();
                }
              },
            }),
            h(
              'button',
              {
                type: 'button',
                className: 'dsh-msg-btn dsh-msg-btn--primary',
                disabled: !draft.trim(),
                onClick: () => void handleSend(),
              },
              t('send'),
            ),
          ),
        );
      }

      return h(
        'div',
        { className: 'dsh-msg-root' },
        rail,
        h('div', { className: 'dsh-msg-main' }, main),
        renderOverlay(),
      );
    }

    /* ------------------------------------------------------------------ *
     * Plugin
     * ------------------------------------------------------------------ */

    return {
      inject: ['slots', 'locale'],
      apply(ctx) {
        const t = ctx.locale.bind(NS);

        ctx.effect(() => {
          const disposers = [];
          const ids = new Set(['en', 'zh', 'zh-Hans', 'zh-CN', 'zh-TW']);
          try {
            for (const locale of ctx.locale.getSnapshot().locales) ids.add(locale.id);
          } catch (err) {
            /* keep the shipped tags */
          }
          for (const id of ids) {
            const dict = String(id).toLowerCase().indexOf('zh') === 0 ? DICTS.zh : DICTS.en;
            try {
              disposers.push(ctx.locale.register(NS, id, dict));
            } catch (err) {
              /* already registered */
            }
          }
          return () => {
            for (const dispose of disposers.reverse()) {
              try {
                dispose();
              } catch (err) {
                /* ignore */
              }
            }
          };
        }, 'chat-room-locale');

        // Register this plugin's release list with the Notes plugin. Exactly one
        // registration per plugin: the service keys descriptors by plugin id.
        ctx.effect(() => {
          const descriptor = {
            id: 'dsh-chat-room',
            title: { zh: '消息', en: 'Messages' },
            noteTitle: { zh: '消息版本记录', en: 'Messages version log' },
            previousNoteTitles: [
              { zh: '联系人版本记录', en: 'Contacts version log' },
              { zh: '消息插件版本记录', en: 'Messages plugin version log' },
            ],
            version: '1.5.3',
            entries: [
              {
                version: '1.5.3',
                at: '2026-10-26T19:00+08:00',
                source: 'harness',
                points: {
                  zh: [
                    '打开消息面板时立刻查一次更新，红点不用再等半小时（服务端有 5 分钟节流，手动点「检查更新」会强制查）',
                    '更新源改为公网清单地址，插件自己从 GitHub 上的 release.json 取新版本',
                  ],
                  en: [
                    'The panel checks for a new version as soon as it opens, so the red dot does not wait half an hour (the server throttles to five minutes; the manual check forces it)',
                    'The update source is now a public manifest address: the plugin reads new versions from release.json on GitHub',
                  ],
                },
              },
              {
                version: '1.5.2',
                at: '2026-10-26T18:40+08:00',
                source: 'harness',
                points: {
                  zh: [
                    '自动更新全链路实测通过：读清单 → 下载 → 校验 sha256 → 换包 → 热生效，联系人与聊天记录完整保留，profile 无残留覆盖',
                  ],
                  en: [
                    'The whole automatic update path is verified: read the manifest, download, check the sha256, swap the package, apply it live, with contacts and history intact and no stray override left behind',
                  ],
                },
              },
              {
                version: '1.5.1',
                at: '2026-10-26T18:30+08:00',
                source: 'harness',
                points: {
                  zh: [
                    '修复：自动更新装完后插件没加载——更新流程把插件行停用（为了能卸载旧包），这个停用被写进了 profile 补丁，换完包没清掉，行就一直关着',
                    '现在装完会把插件行重新打开，profile 里不留多余覆盖',
                  ],
                  en: [
                    'Fixed: after an automatic update the plugin did not load; the row was switched off so the old package could be removed, that switch was remembered in the profile and never cleared, so the row stayed off',
                    'The row is switched on again after the update, leaving no stray override behind',
                  ],
                },
              },
              {
                version: '1.5.0',
                at: '2026-10-26T18:10+08:00',
                source: 'harness',
                points: {
                  zh: [
                    '更新源现在也接受一个 https 的「发布清单」地址：插件读清单拿到新版本号、下载地址和 sha256，下载后校验再安装',
                    '这样不需要 npm 账号——把安装包和 release.json 放在一个公开仓库里即可',
                    '新增 scripts/release.sh：一条命令完成打包、写清单、推送',
                  ],
                  en: [
                    'The update source now also takes an https release manifest: the plugin reads the version, the download address and the sha256 from it, verifies the download and installs it',
                    'That removes the need for an npm account; the package and a release.json in a public repository are enough',
                    'New scripts/release.sh: one command builds, writes the manifest and pushes',
                  ],
                },
              },
              {
                version: '1.4.11',
                at: '2026-10-26T17:55+08:00',
                source: 'harness',
                points: {
                  zh: [
                    '对方装上就能自动更新，不用再设置：发布版的包名就是发布名，插件据此自动填好更新源',
                    '本地开发版（@local/ 开头）不会去 registry 找自己',
                  ],
                  en: [
                    'Installing it is enough: a published package carries the name its releases live under, so the update source fills itself in',
                    'A workspace install (a scoped name) never looks itself up on the registry',
                  ],
                },
              },
              {
                version: '1.4.10',
                at: '2026-10-26T17:40+08:00',
                source: 'harness',
                points: {
                  zh: [
                    '修复关键打包问题：发出去的包里补丁行名还是 @local/chat-room，与包名 dsh-chat-room 不一致，在对方机器上插件根本装不上（1.3.0 起的所有包都中招）',
                    '打包时统一改名：package.json、补丁行、客户端模块 id 三处一致',
                    '新增构建期自检：三者不一致直接构建失败',
                  ],
                  en: [
                    'Fixed a packaging fault: the shipped package still named the patch row @local/chat-room while the package was dsh-chat-room, so the plugin could not load on the other machine (every package since 1.3.0 was affected)',
                    'The build now renames all three: package.json, the patch row and the client module id',
                    'New build-time check: the build fails when they disagree',
                  ],
                },
              },
              {
                version: '1.4.9',
                at: '2026-10-26T17:55+08:00',
                source: 'harness',
                points: {
                  zh: [
                    '更新失败时不再只说「请重试」，会说明具体原因（包名不对、不是插件包、没发布、没有插件管理器等）',
                    '模拟版本现在可以「安装」：点立即更新会走完整个流程，红点消失，方便在没有发布的情况下验证交互',
                  ],
                  en: [
                    'A failed update now says why (wrong name, not a plugin package, nothing published, no plugin manager) instead of a bare "please retry"',
                    'A simulated version can now be "installed": the whole flow runs and the red dot goes away, so the interaction can be checked without publishing',
                  ],
                },
              },
              {
                version: '1.4.8',
                at: '2026-10-26T17:45+08:00',
                source: 'harness',
                points: {
                  zh: [
                    '更新红点改成小一点的实心圆点，去掉白色描边，看着像真正的提醒点',
                  ],
                  en: [
                    'The update dot is a smaller solid round dot without the white ring, so it reads as a real notification',
                  ],
                },
              },
              {
                version: '1.4.7',
                at: '2026-10-26T17:35+08:00',
                source: 'harness',
                points: {
                  zh: [
                    '修复：红点是白的——错误色 token 写错了（应为 --dsw-alias-state-error-primary），取不到值时背景透明，只剩白色描边',
                    '全文件核对了主题 token 引用，只此一处无效',
                  ],
                  en: [
                    'Fixed: the dot was white; the error colour token was wrong (--dsw-alias-state-error-primary is the real one), so the background was transparent and only the white ring showed',
                    'Every theme token in the file was checked against the catalog; this was the only invalid one',
                  ],
                },
              },
              {
                version: '1.4.6',
                at: '2026-10-26T17:25+08:00',
                source: 'harness',
                points: {
                  zh: [
                    '修复：侧栏入口的红点还是看不见——样式表原来由面板注入，面板没打开时红点没有任何样式',
                    '样式表改为插件加载时注入一次，侧栏红点、齿轮红点在任何页面都有效',
                  ],
                  en: [
                    'Fixed: the sidebar dot was still invisible; the stylesheet was injected by the panel, so with the panel closed the dot had no rules at all',
                    'The stylesheet is now injected once when the plugin loads, so the sidebar dot and the gear dot work on every page',
                  ],
                },
              },
              {
                version: '1.4.5',
                at: '2026-10-26T17:45+08:00',
                source: 'harness',
                points: {
                  zh: [
                    '修复：侧栏入口的红点不亮——状态帧里直接就是 state 本身，之前的解析多套了一层，图标一直没收到更新状态',
                    '侧栏图标现在会在有新版时亮红点',
                  ],
                  en: [
                    'Fixed: the red dot on the sidebar entry never appeared; the state frame carries the state itself, and the parser expected a wrapper, so the icon never learned about an update',
                    'The sidebar entry now shows the red dot when a version is available',
                  ],
                },
              },
              {
                version: '1.4.4',
                at: '2026-10-26T17:35+08:00',
                source: 'harness',
                points: {
                  zh: [
                    '修复：侧栏「消息」入口在有新版时可能整行消失——图标组件用了作用域外的翻译函数，渲染时抛错',
                    '翻译函数改为从属性传入，并且缺失时降级而不是崩溃',
                  ],
                  en: [
                    'Fixed: the Messages entry in the sidebar could disappear when a version was available; the icon used a translator from another scope and threw while rendering',
                    'The translator now comes in as a prop and degrades instead of throwing',
                  ],
                },
              },
              {
                version: '1.4.3',
                at: '2026-10-26T17:25+08:00',
                source: 'harness',
                points: {
                  zh: [
                    '有新版时不再弹横幅，只在两个地方透一个小红点：设置齿轮的右上角，和左侧「消息」入口的图标上',
                    '点齿轮进设置，里面直接有「立即更新」按钮',
                  ],
                  en: [
                    'An available version no longer shows a banner: a small red dot appears in two places, on the settings gear and on the Messages entry in the sidebar',
                    'Open the settings to update; the "Update now" button is right there',
                  ],
                },
              },
              {
                version: '1.4.2',
                at: '2026-10-26T17:12+08:00',
                source: 'harness',
                points: {
                  zh: [
                    '联系人信息弹窗改名「编辑」，对话右上角的入口也改成「编辑」',
                    '新增测试开关：插件数据目录里放一个 fake-update.json 就能模拟「有新版」，方便验证红点和更新提示',
                  ],
                  en: [
                    'The contact dialog is now called "Edit", and the entry in the conversation header says "Edit" too',
                    'New test switch: a fake-update.json in the plugin data folder simulates an available version, so the red dot and the update prompt can be checked',
                  ],
                },
              },
              {
                version: '1.4.1',
                at: '2026-10-26T17:10+08:00',
                source: 'harness',
                points: {
                  zh: [
                    '设置按钮换成真正的齿轮图标（原来那个像太阳）',
                    '有新版时，齿轮右上角亮一个红点，鼠标移上去直接告诉你是什么版本',
                  ],
                  en: [
                    'The settings button is a real cog now; the old one read as a sun',
                    'When a new version waits, a red dot appears on the gear and hovering it says which version it is',
                  ],
                },
              },
              {
                version: '1.4.0',
                at: '2026-10-26T16:35+08:00',
                source: 'harness',
                points: {
                  zh: [
                    '插件现在能自己查更新：设置里填一次更新源（npm 包名），之后它会定期检查，发现新版本就在面板顶部提示，点一下即可安装，装完即时生效、不用重启 DSH',
                    '更新源可以写进添加码，对方加你时自动学到更新地址，之后不用再传文件',
                    '安全：只接受 npm 包名（拒绝路径和网址），且只允许替换成同一个包；指向别的包会被拒绝，不会把现有插件卸掉',
                    '自愈：上次启动失败留下的路由会自动释放，不用再重启 DSH',
                  ],
                  en: [
                    'The plugin can now check for updates itself: set the update source (an npm package name) once in the settings and it checks regularly, then offers the update in the panel; installing it applies immediately without restarting DSH',
                    'The update source can travel inside the add code, so the other person learns where updates live without exchanging files',
                    'Safety: only npm package names are accepted (paths and urls are refused) and only the same package may replace this one, so a stray source can never take the working plugin away',
                    'Self-healing: a route left behind by a failed start is released automatically, so no restart is needed',
                  ],
                },
              },
              {
                version: '1.3.0',
                at: '2026-10-26T16:12+08:00',
                source: 'harness',
                points: {
                  zh: [
                    '别人添加我后立刻出现在我的消息列表：添加时向对方收件会话发一个 ping，对方收到即自动建好联系人，不用等对方先发消息',
                    '联系方式可辨：列表显示「对方添加了你」或「对方发来消息，已自动添加」，对话头部有对应标签',
                    '备注名更好改了：左侧点联系人名字即可改名（原先只能进「信息」弹窗找输入框）',
                  ],
                  en: [
                    'A contact that adds you now appears in your list right away: adding sends a ping to their inbox, so they show up without waiting for a first message',
                    'The origin is visible: the list says "They added you" or "They wrote first", and the conversation header carries the same tag',
                    'Renaming is one click away: click a name in the list to rename it, instead of hunting for the field inside the info dialog',
                  ],
                },
              },
              {
                version: '1.2.3',
                at: '2026-10-26T16:05+08:00',
                source: 'harness',
                points: {
                  zh: [
                    '修好「加了人却看不出来」：默认昵称从人人相同的「我」改成每台机器唯一的「用户-xxxx」，双方昵称不再撞名',
                    '历史默认值「我」不再作为联系人名显示，改为「未命名联系人」并标注「未设置昵称」',
                    '自动添加的联系人带「新」标记，说明写清「对方发来消息，已自动添加」，可直接改备注名',
                    '底部提示「点右侧齿轮改个昵称」，自己的身份在会话里不再和对方混淆',
                  ],
                  en: [
                    'Fixed the invisible contact: the shared default name is now a unique "用户-xxxx" per install, so two people never look alike',
                    'The old shared default is no longer shown as a contact name; it reads "Unnamed contact" with a "no display name yet" chip',
                    'Automatically added contacts carry a "NEW" badge and an explanation, and can be renamed right away',
                    'The footer nudges you to set your own name, so your identity is never confused with the other person',
                  ],
                },
              },
              {
                version: '1.2.2',
                at: '2026-10-26T15:44+08:00',
                source: 'harness',
                points: {
                  zh: [
                    '安装只需 1 次授权：改用 .tgz 插件包，install_bundle 可直接安装，不用解压、不用 shell',
                    '口令改成可直接照抄的一句，并明确要求只调用 plugin_manager、不要执行其它命令（避免 agent 自行跑 dsh --dump-config 之类的命令）',
                    '补充：若 DSH 没有 plugin_manager 工具，先把模式从「标准模式」切到「Creator 模式」',
                  ],
                  en: [
                    'Installation now needs a single approval: the package ships as a .tgz that install_bundle takes directly, with no unzip and no shell',
                    'The install phrase is now copy-pasteable and says to call only plugin_manager and run no other commands, so the agent does not improvise CLI calls',
                    'Added: if DSH has no plugin_manager tool, switch the mode from Standard to Creator first',
                  ],
                },
              },
              {
                version: '1.2.1',
                at: '2026-10-26T14:30+08:00',
                source: 'harness',
                points: {
                  zh: ['补充：侧边栏底部常驻「我的码」入口，有联系人之后也能随时复制自己的添加码'],
                  en: ['Added: a persistent "My code" entry in the sidebar footer so your add code stays reachable once contacts exist'],
                },
              },
              {
                version: '1.2.0',
                at: '2026-10-26T14:33+08:00',
                source: 'harness',
                points: {
                  zh: [
                    '改成「每个 ID 自带收件会话」：添加码就是你的 ID，粘贴即可加人，不再需要先「新建联系人」',
                    '面板只保留【添加联系人】与【我的添加码】；对方发来第一条消息时自动成为联系人',
                    '对方入群只需两步：把 zip 拖进 DSH 输入框并说一句「安装我刚上传的联系人插件」，再打开消息面板粘贴添加码',
                    '修复：断线重连后自动补拉会话历史；历史加载失败可在会话里直接重试',
                    '修复：清空记录后列表预览不再残留；自己的消息不再计入未读',
                    '修复：切换联系人失败会提示；发送失败不会覆盖发送期间新输入的文字',
                  ],
                  en: [
                    'Every installation now owns an inbox topic: the add code is your id, so pasting it is enough and no "create contact" step exists',
                    'The panel keeps only "Add contact" and "My add code"; a first message from a stranger creates the contact automatically',
                    'Two steps for the other person: drop the zip into the DSH message box and say one phrase, then paste the add code in the Messages panel',
                    'Fixed: a reconnected page stream refetches conversation history; a failed history load can be retried in place',
                    'Fixed: clearing history no longer leaves a stale preview; your own messages are not counted as unread',
                    'Fixed: switching contacts reports failures; a failed send no longer overwrites text typed while it was in flight',
                  ],
                },
              },
              {
                version: '1.1.2',
                at: '2026-10-26T14:17+08:00',
                source: 'harness',
                points: {
                  zh: [
                    '修复：打开从未看过的联系人时只显示挂载后收到的新消息；改为首次打开拉取历史并与实时消息合并',
                    '修复：发送失败后切换到别的对话时，不再把草稿塞进新对话框',
                    '修复：新建联系人后名片弹窗不再沿用上一个联系人的状态',
                  ],
                  en: [
                    'Fixed: opening a never-viewed contact showed only messages received since mount; history is fetched and merged on first open',
                    'Fixed: a failed send no longer moves the draft into a conversation the user switched to',
                    'Fixed: the card dialog for a new contact no longer inherits the previous contact state',
                  ],
                },
              },
              {
                version: '1.1.1',
                at: '2026-10-26T14:13+08:00',
                source: 'harness',
                points: {
                  zh: ['侧边栏与面板标题从「联系人」改为「消息」'],
                  en: ['Renamed the sidebar entry and panel title from Contacts to Messages'],
                },
              },
              {
                version: '1.1.0',
                at: '2026-10-26T14:07+08:00',
                source: 'harness',
                points: {
                  zh: [
                    '改版：从「一个聊天室」改为「联系人列表 + 一对一对话」',
                    '新增：名片机制、每个联系人独立的会话/历史/未读/状态',
                    '兼容：旧版单房间聊天室自动迁移成一条联系人对话',
                  ],
                  en: [
                    'Redesigned from a single chat room into a contact list with one-to-one conversations',
                    'New: contact cards, per-contact conversation, history, unread badges and relay status',
                    'Upgrade path: the previous single-room chat migrates into one contact',
                  ],
                },
              },
              {
                version: '1.0.0',
                at: '2026-10-26T13:26+08:00',
                source: 'harness',
                points: {
                  zh: ['首个版本：侧边栏聊天室面板，创建/加入房间，通过公共中继跨网络收发消息'],
                  en: ['First release: sidebar chat room with create/join room over a public relay'],
                },
              },
            ],
          };
          let handled = false;
          try {
            const service = ctx.get('pluginVersionLog');
            if (service && typeof service.register === 'function') {
              service.register(descriptor);
              handled = true;
            }
          } catch (err) {
            handled = false;
          }
          if (!handled && typeof window !== 'undefined') {
            const sink = window.__dshPluginVersionLogSink;
            if (typeof sink === 'function') {
              sink(descriptor);
              handled = true;
            }
          }
          if (!handled && typeof window !== 'undefined') {
            const queue = window.__dshPluginVersionLogQueue || (window.__dshPluginVersionLogQueue = []);
            queue.push(descriptor);
          }
        }, 'chat-room-version-log');

        injectStyles();

        const View = (slotProps) =>
          h(ContactsPanel, Object.assign({}, slotProps, { t, locale: ctx.locale }));

        const PanelIcon = (slotProps) =>
          h(ContactIcon, Object.assign({}, slotProps, { t }));

        // Register the main key first: the sidebar button only navigates to a
        // key that already exists.
        ctx.slots.inject('main', () =>
          ctx.slots.register({ name: 'main', key: PANEL_ID }, View),
        );

        ctx.slots.inject('sidebar.panellist', () =>
          ctx.slots.register(
            {
              name: 'sidebar.panellist',
              id: PANEL_ID,
              order: 7,
              label: () => t('title'),
            },
            PanelIcon,
          ),
        );
      },
    };
  },
});
